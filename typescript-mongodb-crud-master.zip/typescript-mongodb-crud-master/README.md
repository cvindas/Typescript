# Typescript Nodejs Mongodb CRUD
![](docs/screenshot.png)

# Installation
```bash
npm install
npm build
npm start
```